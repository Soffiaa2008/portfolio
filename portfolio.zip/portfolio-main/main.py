#Импорт
from flask import Flask, render_template,request, redirect



app = Flask(__name__)

#Запуск страницы с контентом
@app.route('/',methods=['GET','POST'])
def index():
    if request.method == 'POST':
        email = request.form['email']
        text = request.form['text']
        with open ("mess.txt","a")as f:
            emxt="email:"+email+"/n"+"text:"+text+"/n"
            f.write(emxt)
        return render_template('index.html')
    return render_template('index.html')


#Динамичные скиллы
@app.route('/', methods=['POST'])
def process_form():
    button_python = request.form.get('button_python')
    return render_template('index.html', button_python=button_python)


if __name__ == "__main__":
    app.run(debug=True)